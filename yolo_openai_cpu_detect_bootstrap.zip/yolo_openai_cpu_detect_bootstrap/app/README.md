# Application Package

Application code will be implemented here after the repository bootstrap.

Expected subpackages:

- `api`
- `core`
- `vision`
- `inference`
- `schemas`

Do not add tracking, segmentation, video, background-job, database, or GPU-specific modules without a future approved scope change.
