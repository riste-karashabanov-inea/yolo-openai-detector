# Compatibility docs

OpenAI compatibility notes live here.
