# OpenAI Compatibility Target

## Compatibility level

This project implements an OpenAI-compatible subset, not the full OpenAI API.

## Supported

| OpenAI-style feature | Supported? | Notes |
|---|---:|---|
| Bearer auth | Yes | Fixed local API key |
| `/v1/models` | Yes | One local detection model |
| `/v1/responses` | Yes | Single-image detection subset |
| Base64 data URL image input | Yes | Required transport |
| OpenAI-shaped error object | Yes | Subset |
| OpenAI Python SDK base URL usage | Target | Must be tested later |

## Not supported

| Feature | Reason |
|---|---|
| Complete Responses API | Not needed for detection service |
| Text generation | Not this product |
| Remote image URLs | Avoid network fetch/security issues |
| File IDs | No Files API clone |
| Streaming responses | Synchronous detection only |
| Chat Completions | Optional future adapter only |
| Function calling/tools | Not relevant |
| Upstream OpenAI proxying | Explicitly forbidden |

## Expected SDK usage later

Target usage pattern:

```python
from openai import OpenAI

client = OpenAI(
    api_key="local-fixed-key",
    base_url="http://localhost:8000/v1",
)

response = client.responses.create(
    model="yolo-cpu-detect",
    input=[{
        "role": "user",
        "content": [
            {"type": "input_text", "text": "Detect objects."},
            {"type": "input_image", "image_url": "data:image/jpeg;base64,..."},
        ],
    }],
)
```

This SDK path must be verified in a later implementation PR before it is claimed as working.
