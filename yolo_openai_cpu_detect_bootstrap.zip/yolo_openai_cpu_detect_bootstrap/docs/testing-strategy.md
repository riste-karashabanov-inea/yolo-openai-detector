# Testing Strategy

## First milestone test categories

| Category | Required tests |
|---|---|
| Auth | missing key, wrong key, valid key |
| `/v1/models` | shape, model ID, auth |
| Request parsing | valid Responses-style body |
| Image validation | missing image, more than one image, invalid Base64, unsupported MIME |
| Detection schema | fake backend output is schema-stable |
| Response envelope | OpenAI-shaped response with parseable JSON output text |
| Error envelope | OpenAI-shaped error object |
| Scope guard | no background worker/database/GPU dependency introduced |

## Test naming convention

Use descriptive names:

```python
def test_responses_rejects_more_than_one_image(...):
    ...
```

## Negative tests

Negative path tests are required. The API is not acceptable if it only tests valid requests.

## Skipped tests

A skipped test is not passed. Reports must say skipped/not-run/blocked explicitly.

## Later detector tests

When ONNX/OpenVINO backends are introduced:

- use a fixed test image;
- pin the test model artifact or provide deterministic download instructions;
- define numeric tolerance for bounding boxes;
- run CPU-only environment checks;
- test backend initialization failure.
