# Non-Goals and Forbidden Scope

This document prevents scope creep.

## Non-goals for first release

| Feature | Status | Reason |
|---|---|---|
| Object tracking | Forbidden | User explicitly removed tracking scope |
| Tracking IDs | Forbidden | Single-shot image detection only |
| Segmentation | Forbidden | Detection boxes only |
| Video input | Forbidden | Image-only service |
| Webcam/RTSP | Forbidden | Not part of OpenAI-style image attachment flow |
| Background jobs | Forbidden | Synchronous request/response only |
| Job IDs | Forbidden | No job lifecycle exists |
| Database | Forbidden | No persistence needed |
| Persistent image storage | Forbidden | Privacy and simplicity |
| User accounts | Forbidden | Fixed API key only |
| Billing/quota | Forbidden | Not part of this service |
| GPU inference | Forbidden | Must work on GPU-less machine |
| CUDA/TensorRT | Forbidden | Contradicts CPU-only target |
| OpenAI upstream proxying | Forbidden | Service is local-compatible API, not an OpenAI proxy |

## Agent rule

If a requested change appears to require any forbidden scope, stop and report the conflict. Do not implement adjacent features because they seem useful.

## Documentation rule

Docs must not imply support for forbidden scope. Do not use wording such as:

- real-time tracking;
- video analytics;
- segmentation output;
- background processing;
- GPU acceleration;
- production-ready;
- complete OpenAI API implementation.

Use precise wording:

- CPU-only;
- single-image;
- synchronous;
- detection boxes only;
- OpenAI-compatible subset.
