# Architecture

## Context

The service is a local CPU-only object detection gateway. It is shaped like an OpenAI API server so client code can use familiar API conventions.

## High-level flow

```text
HTTP client
  -> FastAPI app
  -> Bearer auth dependency
  -> request schema validation
  -> image extraction from data URL
  -> image decode and validation
  -> detector backend abstraction
  -> detection schema
  -> OpenAI-shaped response envelope
```

## Proposed modules

| Module | Responsibility |
|---|---|
| `app/api/auth.py` | Bearer API key validation |
| `app/api/health.py` | Health endpoint |
| `app/api/models.py` | `/v1/models` endpoint |
| `app/api/responses.py` | `/v1/responses` endpoint |
| `app/core/config.py` | Environment-driven settings |
| `app/core/errors.py` | OpenAI-shaped error helpers |
| `app/core/logging.py` | Safe structured logging |
| `app/vision/image_input.py` | Extract image data URL from request |
| `app/vision/validation.py` | MIME, size, and image-count validation |
| `app/vision/decoding.py` | Base64 and image decoding |
| `app/inference/base.py` | Detector interface |
| `app/inference/fake_backend.py` | Deterministic fake detector for tests |
| `app/inference/onnx_backend.py` | Later ONNX Runtime CPU backend |
| `app/inference/openvino_backend.py` | Later OpenVINO backend |
| `app/schemas/openai.py` | OpenAI-shaped request/response schemas |
| `app/schemas/detection.py` | Internal detection schemas |

## Backend abstraction

Every detector backend must implement a common interface equivalent to:

```python
class DetectorBackend:
    name: str
    device: str = "cpu"

    def detect(self, image: DecodedImage) -> DetectionResult:
        ...
```

Rules:

- Backends return internal schema objects, not OpenAI envelopes.
- API layer wraps backend output into the OpenAI-shaped response.
- Backend must report backend name, device, and measured inference time.
- Backend must not know about API keys or HTTP.

## First backend

The first backend is fake and deterministic. It is only for contract and integration tests.

Purpose:

- prove API flow;
- avoid coupling first PR to model files;
- make tests deterministic;
- make negative path testing fast.

## Later backends

Preferred order:

1. ONNX Runtime CPU backend.
2. OpenVINO backend.
3. Optional export utilities for YOLO model conversion.

GPU-specific backends are forbidden unless the project scope is explicitly changed.

## Deployment shape

Initial target:

```text
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Later Docker target:

```text
CPU-only container
  -> FastAPI/Uvicorn
  -> local model file mounted read-only
  -> fixed API key from environment
```

No database, worker, Redis, or persistent volume is required for the first release.
