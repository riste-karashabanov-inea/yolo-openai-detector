# Operational Limits

This document defines expected limits for the first implementation.

## Input limits

| Limit | Initial value | Notes |
|---|---:|---|
| Images per request | `1` | More than one image must be rejected |
| MIME types | JPEG, PNG | WebP only if explicitly tested |
| Max decoded image bytes | 10 MiB | Configurable |
| Max image width | 4096 px | Configurable |
| Max image height | 4096 px | Configurable |
| Remote image URLs | Not supported | Data URL only |
| File IDs | Not supported | No OpenAI Files API clone |

## Runtime limits

| Limit | First release decision |
|---|---|
| CPU only | Required |
| GPU | Unsupported |
| Batch inference | Unsupported |
| Background jobs | Unsupported |
| Concurrent model loading | Unsupported until benchmarked |

## Performance claims

Do not claim a throughput or latency number until benchmark evidence exists.

Benchmark reports must include:

- CPU model;
- RAM;
- OS/container environment;
- backend;
- model file;
- image size;
- warmup count;
- measured latency distribution;
- whether preprocessing/postprocessing is included.
