# Model Runtime Strategy

## Goal

Support CPU-only YOLO object detection with a backend abstraction.

## Backend order

| Stage | Backend | Purpose |
|---|---|---|
| M1 | Fake deterministic backend | API and schema tests |
| M2 | ONNX Runtime CPU | Portable CPU inference |
| M3 | OpenVINO | Optimized Intel CPU path |

## Production runtime principle

The default production runtime must not require GPU hardware or GPU drivers.

## Model files

Do not commit large model binaries to the repository.

Recommended later approach:

- keep `models/README.md` with expected model locations;
- mount model files at runtime;
- use checksums for known model artifacts;
- document export commands separately.

## YOLO export policy

If Ultralytics is used, it should be used primarily for model export and validation tooling, not as the mandatory production inference runtime.

## Backend output contract

Every backend must return:

- detections list;
- image width/height;
- backend name;
- device name, expected `cpu`;
- inference time in milliseconds.
