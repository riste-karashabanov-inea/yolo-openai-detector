# API Contract

This document defines the API contract for the OpenAI-compatible CPU single-image detection service.

## Authentication

All `/v1/*` endpoints require:

```http
Authorization: Bearer <DETECT_API_KEY>
```

Rules:

- API key is configured through environment variable `DETECT_API_KEY`.
- Missing key returns `401`.
- Wrong key returns `401`.
- Malformed Authorization header returns `401`.
- Authentication must occur before image decoding and inference.

## Health endpoint

```http
GET /health
```

Suggested response:

```json
{
  "status": "ok",
  "service": "yolo-openai-cpu-detect"
}
```

The health endpoint may be public unless deployment policy requires auth. `/v1/*` endpoints must require auth.

## Model list endpoint

```http
GET /v1/models
Authorization: Bearer <DETECT_API_KEY>
```

Response:

```json
{
  "object": "list",
  "data": [
    {
      "id": "yolo-cpu-detect",
      "object": "model",
      "created": 0,
      "owned_by": "local"
    }
  ]
}
```

## Detection endpoint

```http
POST /v1/responses
Authorization: Bearer <DETECT_API_KEY>
Content-Type: application/json
```

### Request

```json
{
  "model": "yolo-cpu-detect",
  "input": [
    {
      "role": "user",
      "content": [
        {
          "type": "input_text",
          "text": "Detect objects in this image."
        },
        {
          "type": "input_image",
          "image_url": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQ..."
        }
      ]
    }
  ]
}
```

### Supported image data URLs

Required:

- `data:image/jpeg;base64,...`
- `data:image/png;base64,...`

Optional only if tested:

- `data:image/webp;base64,...`

### Request validation

| Condition | Status | Error code |
|---|---:|---|
| Missing/invalid auth | `401` | `invalid_api_key` |
| Unsupported model | `400` | `unsupported_model` |
| Missing input image | `400` | `invalid_request_error` |
| More than one image | `400` | `invalid_request_error` |
| Unsupported MIME type | `400` | `unsupported_image_type` |
| Invalid Base64 | `400` | `invalid_image` |
| Image too large | `413` or `400` | `image_too_large` |
| Inference backend unavailable | `503` | `backend_unavailable` |

## Detection result schema

The response envelope is OpenAI-shaped. The detection JSON is returned as output text.

Detection JSON:

```json
{
  "detections": [
    {
      "class_id": 0,
      "class_name": "person",
      "confidence": 0.91,
      "bbox_xyxy": [120.4, 44.1, 188.2, 210.8]
    }
  ],
  "image": {
    "width": 1280,
    "height": 720
  },
  "runtime": {
    "backend": "fake",
    "device": "cpu",
    "inference_ms": 0.0
  }
}
```

## Response envelope

Suggested OpenAI-shaped response:

```json
{
  "id": "resp_local_0000000000000001",
  "object": "response",
  "created_at": 0,
  "model": "yolo-cpu-detect",
  "output": [
    {
      "type": "message",
      "role": "assistant",
      "content": [
        {
          "type": "output_text",
          "text": "{\"detections\":[...]}"
        }
      ]
    }
  ]
}
```

## Error envelope

Use an OpenAI-shaped error object:

```json
{
  "error": {
    "message": "Unsupported model: abc",
    "type": "invalid_request_error",
    "param": "model",
    "code": "unsupported_model"
  }
}
```

## Compatibility note

This service does not implement the complete OpenAI Responses API. It implements the subset required for single-image detection through a compatible HTTP shape.
