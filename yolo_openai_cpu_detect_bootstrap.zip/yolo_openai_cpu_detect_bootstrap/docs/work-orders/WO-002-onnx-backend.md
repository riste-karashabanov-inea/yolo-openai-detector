# Work Order 002 — ONNX Runtime CPU Backend Placeholder

Status: draft only. Do not execute until WO-001 is merged and reviewed.

## Goal

Add the first real CPU detector backend using ONNX Runtime CPU.

## Preconditions

- WO-001 scaffold is merged.
- API contract tests pass.
- A model artifact strategy is approved.
- A fixed test image is available.

## Non-goals

- No OpenVINO yet.
- No tracking.
- No segmentation.
- No video.
- No GPU packages.

## Notes

This file is intentionally a placeholder to show milestone sequence. A strategic agent must rewrite this work order using current repository state before execution.
