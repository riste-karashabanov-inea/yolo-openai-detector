# Work Order 001 — API Scaffold With Fake Detector

## Governing instructions

Read `AGENTS.md` first. Follow all project rules. This is the first implementation task after the repository bootstrap.

## Current state

The repository contains project constitution, documentation, dependency manifests, and empty directory structure. No application code is implemented yet.

## Goal

Create the first working API scaffold for a CPU-only OpenAI-compatible single-image detection service.

## Required endpoints

- `GET /health`
- `GET /v1/models`
- `POST /v1/responses`

## Required behavior

### Authentication

- Use fixed Bearer API key from environment variable `DETECT_API_KEY`.
- Require authentication for `/v1/models` and `/v1/responses`.
- Reject missing/wrong API key with `401` before image decoding and detector execution.

### `/v1/models`

Return an OpenAI-shaped model list with one model:

- `id`: `yolo-cpu-detect`
- `object`: `model`
- `owned_by`: `local`

### `/v1/responses`

- Accept Responses-style JSON input.
- Extract exactly one image from `content` where `type == "input_image"`.
- Accept Base64 data URL image input.
- Decode JPEG and PNG.
- Reject missing image.
- Reject more than one image.
- Reject invalid Base64.
- Reject unsupported MIME type.
- Use fake deterministic backend.
- Return OpenAI-shaped response with detection JSON as output text.

## Fake backend behavior

Return a deterministic result based on decoded image dimensions. Example acceptable output:

```json
{
  "detections": [
    {
      "class_id": 0,
      "class_name": "test_object",
      "confidence": 0.99,
      "bbox_xyxy": [0.0, 0.0, 10.0, 10.0]
    }
  ],
  "image": {
    "width": 32,
    "height": 32
  },
  "runtime": {
    "backend": "fake",
    "device": "cpu",
    "inference_ms": 0.0
  }
}
```

## Non-goals

Do not implement:

- real YOLO inference;
- ONNX Runtime;
- OpenVINO;
- tracking;
- segmentation;
- video;
- background jobs;
- database;
- persistent image storage;
- GPU/CUDA/TensorRT support.

## Files expected to change

Likely areas:

- `app/api/`
- `app/core/`
- `app/vision/`
- `app/inference/`
- `app/schemas/`
- `tests/`
- `README.md` if quickstart changes are needed
- `docs/api-contract.md` only if behavior is clarified without changing approved scope

## Required tests

Add tests for:

- missing API key rejected;
- wrong API key rejected;
- valid API key accepted;
- `/v1/models` shape;
- missing image rejected;
- more than one image rejected;
- invalid Base64 rejected;
- unsupported MIME type rejected;
- valid JPEG data URL succeeds;
- valid PNG data URL succeeds;
- response output text is parseable JSON;
- detection schema fields exist and are correct.

## Required commands

At minimum run:

```bash
python -m pytest
ruff check .
```

If `ruff` is not configured yet, configure it in this PR and report the exact command.

## Final report

Use the report format from `AGENTS.md`.
