# Project Baseline v0.1

Date: 2026-06-29

## Approved understanding

This project will implement a CPU-only YOLO single-image object detection API with an OpenAI-compatible interface.

## Baseline decisions

| Area | Decision |
|---|---|
| Product | Single-image object detection service |
| Detector family | YOLO-compatible detector |
| Runtime | CPU-only |
| Interface | OpenAI-style HTTP API |
| Auth | Fixed Bearer API key |
| Input | One Base64 data URL image inside JSON request |
| Output | OpenAI-shaped response with strict detection JSON |
| Processing | Synchronous request/response |
| First detector backend | Fake deterministic backend for scaffold tests |
| Later detector backend | ONNX Runtime CPU first, OpenVINO optional afterward |

## Required first endpoints

| Endpoint | Purpose |
|---|---|
| `GET /health` | Liveness/readiness smoke endpoint |
| `GET /v1/models` | OpenAI-compatible model list |
| `POST /v1/responses` | Single-image detection |

## Explicit exclusions

- No tracking.
- No segmentation.
- No video.
- No background jobs.
- No database.
- No persistent storage.
- No GPU dependencies.
- No upstream OpenAI API calls.

## First implementation milestone

Milestone M1 implements the API scaffold, fixed-key authentication, image extraction/validation, fake backend, OpenAI-shaped responses/errors, tests, and documentation.

M1 must not implement real YOLO inference. Real inference starts in M2 after the API contract is verified.
