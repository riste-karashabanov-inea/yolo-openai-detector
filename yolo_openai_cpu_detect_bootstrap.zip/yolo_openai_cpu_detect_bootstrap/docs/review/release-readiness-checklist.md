# Release Readiness Checklist

Use before any tagged release.

- [ ] Release goal is explicit.
- [ ] Release scope matches documentation.
- [ ] API contract is current.
- [ ] Non-goals are still respected.
- [ ] All release-relevant tests pass.
- [ ] No required tests are skipped without explicit blocker classification.
- [ ] Security review completed.
- [ ] Benchmark claims, if any, are backed by measured evidence.
- [ ] Docker/deployment docs are verified if included in release.
- [ ] Known limitations are documented.
- [ ] Human release authority accepts the remaining risks.
