# PR Readiness Checklist

Use this checklist before merging any implementation PR.

- [ ] Work order was read and followed.
- [ ] `AGENTS.md` was followed.
- [ ] Scope matches the task.
- [ ] No forbidden feature was introduced.
- [ ] No unrelated files changed.
- [ ] Tests were added or updated.
- [ ] Negative paths are tested.
- [ ] Tests were run and exact results are reported.
- [ ] Skipped tests are reported as skipped, not passed.
- [ ] Docs are updated when behavior changed.
- [ ] No real secrets are committed.
- [ ] Authorization headers are not logged.
- [ ] Images are not persisted unless explicitly approved.
- [ ] No GPU dependency was added.
- [ ] Response shape remains documented.
- [ ] Reviewer can explain what evidence proves the change.
