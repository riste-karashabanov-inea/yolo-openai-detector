# Security and Data Handling

## Authentication

The service uses a fixed API key loaded from `DETECT_API_KEY`.

Required header:

```http
Authorization: Bearer <DETECT_API_KEY>
```

Rules:

- API key must not be hardcoded.
- API key must not be committed.
- API key must not be logged.
- Missing/wrong key must fail before image decoding and inference.

## Input data

Input images are sensitive request-local data.

Rules:

- Do not store image bytes in the first release.
- Do not write uploaded images to disk by default.
- Do not log Base64 data.
- Do not include image data in error responses.
- Do not accept remote image URLs in the first release.

## Request limits

Settings must include limits for:

- maximum request body size, where framework support permits;
- maximum decoded image bytes;
- maximum image width;
- maximum image height;
- allowed MIME types.

Suggested initial defaults:

| Setting | Default |
|---|---:|
| `MAX_IMAGE_BYTES` | `10485760` / 10 MiB |
| `MAX_IMAGE_WIDTH` | `4096` |
| `MAX_IMAGE_HEIGHT` | `4096` |

These values may be adjusted after benchmarking.

## Error handling

Errors must not expose:

- API keys;
- image content;
- local file paths containing secrets;
- full tracebacks in production mode.

## Dependency safety

Do not add large or risky dependencies without a specific work order.
GPU-specific dependencies are forbidden in default runtime.
