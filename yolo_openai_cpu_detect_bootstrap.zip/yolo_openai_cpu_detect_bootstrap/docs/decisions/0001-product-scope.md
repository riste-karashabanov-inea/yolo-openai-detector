# ADR 0001 — Product Scope

Date: 2026-06-29

## Status

Accepted.

## Decision

Build a CPU-only, OpenAI-compatible, single-image YOLO object detection API.

## Rationale

The intended machine may be GPU-less, so the runtime must be CPU-only. The user wants OpenAI-compatible access using a fixed API key. The accepted scope is single-shot image detection only.

## Consequences

- `/v1/models` remains because OpenAI-compatible clients may expect model discovery.
- `/v1/responses` is the primary detection endpoint.
- Tracking, segmentation, video, and background jobs are explicitly excluded.
- The project must not claim complete OpenAI API compatibility.
