# ADR 0002 — Runtime Backend Sequence

Date: 2026-06-29

## Status

Accepted as initial strategy.

## Decision

Implement backends in this order:

1. Fake deterministic backend for API and contract tests.
2. ONNX Runtime CPU backend.
3. OpenVINO backend if Intel CPU optimization is required.

## Rationale

The fake backend decouples API contract work from model artifact and inference issues. ONNX Runtime CPU is a portable CPU target. OpenVINO can improve CPU deployment on Intel hardware but should not block the initial scaffold.

## Consequences

- Do not add ONNX/OpenVINO dependencies in WO-001 unless explicitly needed.
- Keep inference behind an interface from the beginning.
- Do not make PyTorch/Ultralytics the mandatory production path.
