# Benchmarking Plan

Benchmarking starts only after a real CPU detector backend exists.

## Required metrics

- image decode time;
- preprocessing time;
- inference time;
- postprocessing time;
- total request time;
- process RSS memory;
- CPU model;
- number of threads used;
- backend name;
- model name/path/hash;
- image dimensions.

## Minimum benchmark matrix

| Variable | Values |
|---|---|
| Backend | ONNX Runtime CPU, OpenVINO if implemented |
| Image size | 640 px, 1280 px, native test image |
| Model | smallest approved YOLO model first |
| Warmup | at least 5 requests |
| Measurement | at least 50 requests |

## Reporting rule

Do not publish performance claims without the full environment metadata.
