# Claude Project Constitution: OpenAI-Compatible CPU YOLO Single-Image Detection API

This file is the governing instruction set for all coding agents working in this repository. It is project law. Read it before making any changes.

`CLAUDE.md` must remain operationally equivalent to this file. If this file changes, update `CLAUDE.md` in the same PR unless explicitly instructed otherwise.

## 1. Discovery summary

### Domain problem

We need a local, CPU-only object detection API that can be called through an OpenAI-compatible HTTP interface. The service should let users submit exactly one image as an attached Base64 image payload and receive object detections from a local YOLO runtime.

### Chosen product shape

This is not an object tracking system and not a generic OpenAI proxy. It is a synchronous single-image object detection service with OpenAI-style request and response conventions.

### First release scope

The first implementation milestone must provide:

- `GET /health`;
- `GET /v1/models`;
- `POST /v1/responses`;
- fixed Bearer API key authentication;
- exactly one Base64 data URL image per request;
- strict validation and fail-closed error behavior;
- deterministic fake detector backend for tests;
- OpenAI-shaped response envelope;
- documented internal detection JSON schema;
- unit tests for authentication, validation, and response shape.

### Architecture decision

Use Python with FastAPI for the HTTP API. Use a detector abstraction so the first implementation can use a fake deterministic backend, later ONNX Runtime, and later OpenVINO.

### Runtime decision

Production target is CPU-only. GPU dependencies are forbidden in the default runtime.

## 2. Mission

Build a small, auditable, OpenAI-compatible, CPU-only single-image object detection API.

The core user promise is:

> A client can submit one image using an OpenAI-style request and receive schema-stable YOLO object detections from a local CPU runtime.

Do not break this promise with broad features, hidden state, or unverified claims.

## 3. Hard scope boundaries

### Required

- OpenAI-style Bearer authentication.
- `/v1/models` compatibility endpoint.
- `/v1/responses` detection endpoint.
- One image per request.
- Image must be supplied inside the request JSON as a Base64 data URL.
- Synchronous request/response processing.
- CPU-only runtime.
- Strict JSON-compatible detection result.
- Tests for all validation decisions.

### Forbidden unless a future approved work order explicitly changes scope

- Object tracking.
- Tracking IDs.
- Multi-frame association.
- Segmentation masks.
- Video input.
- Webcam input.
- RTSP streams.
- Background workers.
- Job queues.
- Job IDs.
- Async batch processing.
- Database persistence.
- Persistent image storage.
- User accounts.
- Multi-key admin UI.
- Billing.
- Quota accounting.
- GPU inference.
- CUDA.
- TensorRT.
- Production OpenAI upstream calls.
- Proxying requests to OpenAI.

## 4. API contract invariants

### Authentication

- Use `Authorization: Bearer <key>`.
- The configured fixed API key comes from environment variable `DETECT_API_KEY`.
- Missing, malformed, or wrong key must return `401`.
- Authentication must happen before body parsing, image decoding, inference, or expensive validation wherever FastAPI dependency order permits.
- Never log the received API key.
- Never commit a real API key.

### `/v1/models`

- Return an OpenAI-shaped model list object.
- First implementation exposes exactly one model ID: `yolo-cpu-detect`.
- The endpoint must require authentication unless a future work order explicitly makes it public.

Expected shape:

```json
{
  "object": "list",
  "data": [
    {
      "id": "yolo-cpu-detect",
      "object": "model",
      "created": 0,
      "owned_by": "local"
    }
  ]
}
```

### `/v1/responses`

- Accept OpenAI Responses-style input.
- Extract exactly one `input_image` content item.
- The supported `image_url` value is a data URL:
  - `data:image/jpeg;base64,...`
  - `data:image/png;base64,...`
  - optionally `data:image/webp;base64,...` only if decoder support is tested.
- Reject more than one image.
- Reject missing image.
- Reject unsupported MIME type.
- Reject invalid Base64.
- Reject images above configured size limits.
- Reject unknown model ID.
- Return OpenAI-shaped errors.
- Return OpenAI-shaped response envelope with detection JSON in output text.

## 5. Detection schema invariants

The internal detection result schema must remain stable unless changed by explicit work order and documented migration.

Required detection object:

```json
{
  "class_id": 0,
  "class_name": "person",
  "confidence": 0.91,
  "bbox_xyxy": [120.4, 44.1, 188.2, 210.8]
}
```

Rules:

- `bbox_xyxy` is `[x_min, y_min, x_max, y_max]` in source image pixel coordinates.
- Coordinates are floats.
- Confidence is a float in `[0.0, 1.0]`.
- Class names must come from the loaded model metadata or explicit class map.
- No tracking ID is allowed.
- No segmentation mask is allowed.

## 6. Architecture

Expected package layout:

```text
app/
  api/
  core/
  inference/
  schemas/
  vision/
  tests/
docs/
  compatibility/
  decisions/
  review/
  work-orders/
scripts/
models/
```

### Module ownership

| Area | Responsibility |
|---|---|
| `app/api` | HTTP endpoints, request routing, API-specific translation |
| `app/core` | Settings, errors, logging, constants |
| `app/vision` | Image extraction, decoding, validation, preprocessing |
| `app/inference` | Detector interface and backend implementations |
| `app/schemas` | Pydantic/API schemas and detection schemas |
| `tests` | Unit and integration tests |
| `docs` | API contract, architecture, limits, work orders, review artifacts |
| `scripts` | Local dev and benchmark utilities |
| `models` | Local model placeholders and instructions only; no large model binaries committed |

## 7. Dependency policy

Allowed first-stage dependencies:

- FastAPI.
- Uvicorn.
- Pydantic / pydantic-settings.
- Pillow.
- NumPy.
- pytest.
- httpx for tests.
- ruff.
- mypy only if configured without blocking initial scaffold unnecessarily.

Allowed later by explicit work order:

- onnxruntime CPU package.
- openvino.
- opencv-python-headless if needed.
- ultralytics only for model export tooling, not mandatory production runtime.

Forbidden in default runtime:

- torch with CUDA assumptions.
- CUDA packages.
- TensorRT.
- GPU-specific ONNX Runtime packages.
- Background worker frameworks such as Celery, RQ, Dramatiq.
- Database drivers unless a future approved scope requires persistence.

## 8. Security rules

- Never commit real API keys.
- Never log Authorization headers.
- Never store uploaded images by default.
- Never call upstream OpenAI APIs from this service.
- Never accept remote image URLs in the first release.
- Never process more than one image in the first release.
- Fail closed on unsupported model, MIME type, request shape, or image size.
- Use bounded request body limits where possible.
- Add tests for negative paths, not only success paths.

## 9. Privacy and data handling

- Input images are request-local data.
- The first release must not persist input images.
- Logs must not include image Base64 payloads.
- Logs may include request ID, model ID, validation outcome, image dimensions, and inference time.
- If future persistence is requested, it requires a new data-retention design document and explicit approval.

## 10. Testing requirements

### Required for scaffold PR

- Missing API key rejected.
- Wrong API key rejected.
- Correct API key accepted.
- `/v1/models` returns expected model list.
- Missing image rejected.
- More than one image rejected.
- Invalid Base64 rejected.
- Unsupported MIME rejected.
- Oversized image rejected if size limit is implemented in the scaffold.
- Valid image returns OpenAI-shaped response envelope.
- Detection JSON can be parsed and matches schema.

### Required later for real detector backends

- Backend loads without GPU.
- CPU inference works on a fixed test image.
- Class names and bounding boxes are deterministic within an acceptable tolerance.
- Inference errors return OpenAI-shaped errors.
- Benchmark command reports latency and CPU runtime metadata.

### Test reporting rule

A skipped test is not a passing test. A test that was not run is not evidence.

Every agent report must distinguish:

- passed;
- failed;
- skipped;
- not run;
- blocked.

## 11. Documentation requirements

When behavior changes, update the relevant docs in the same PR.

Required docs:

- `README.md` for project overview.
- `docs/project-baseline.md` for approved scope.
- `docs/api-contract.md` for request/response shape.
- `docs/non-goals.md` for forbidden scope.
- `docs/limits.md` for operational limits.
- `docs/security.md` for auth and data handling.
- `docs/model-runtime.md` for backend decisions.
- `docs/testing-strategy.md` for verification rules.
- `docs/work-orders/` for executable work orders.

Do not claim real-time performance until benchmark evidence exists.
Do not claim production readiness until a release decision brief exists.

## 12. Workflow rules

For all implementation after repository bootstrap:

- Start from current `main`.
- Create a feature branch.
- Keep changes PR-sized.
- Commit only related files.
- Open a PR.
- Do not merge your own PR.
- Include test evidence in the final report.
- Include skipped/not-run tests explicitly.
- Update docs with behavior changes.

The bootstrap commit itself may be committed directly by the human when creating the repository.

## 13. Final report format for coding agents

Every implementation task must end with:

```markdown
## Agent Report

Branch:
Commit:
PR:

## Summary
- ...

## Files changed
- ...

## Tests run
- command: result

## Documentation changed
- ...

## Safety confirmations
- No real API keys committed.
- No Authorization headers logged.
- No image persistence added.
- No tracking/video/segmentation/background-job scope added.
- No GPU dependency added.

## Skipped / not run / blocked
- ...

## Risks and follow-up
- ...
```

## 14. Review checklist

Before merge, reviewer must confirm:

- Scope matches work order.
- No unrelated files changed.
- Tests are meaningful.
- Negative paths are tested.
- Docs match behavior.
- No forbidden features were introduced.
- No secrets were committed.
- Response shape remains OpenAI-compatible enough for the documented target.
- Release language remains honest.

## 15. Current baseline version

Baseline: `v0.1-bootstrap`
Date: 2026-06-29
Status: constitution and repository scaffold only.
