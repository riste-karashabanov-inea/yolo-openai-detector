# Models Directory

Do not commit large model binaries to this repository.

This directory is reserved for documentation, checksums, and local placeholders.

Later implementation may expect a model file to be mounted or copied here locally, but large `.onnx`, `.pt`, `.xml`, `.bin`, or similar artifacts should not be committed unless repository policy explicitly changes.
