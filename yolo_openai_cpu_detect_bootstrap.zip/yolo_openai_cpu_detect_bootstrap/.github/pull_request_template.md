## Summary

- 

## Work order

- [ ] This PR implements an approved work order.
- Work order file: 

## Scope control

- [ ] No tracking added.
- [ ] No segmentation added.
- [ ] No video support added.
- [ ] No background jobs added.
- [ ] No database/persistence added.
- [ ] No GPU/CUDA/TensorRT dependency added.

## Tests

Commands run:

```bash
# paste exact commands and results
```

Skipped / not run / blocked:

- 

## Documentation

- [ ] Docs updated where behavior changed.
- [ ] Docs do not overclaim readiness or unsupported scope.

## Security

- [ ] No real API keys committed.
- [ ] Authorization headers are not logged.
- [ ] Images are not persisted by default.
