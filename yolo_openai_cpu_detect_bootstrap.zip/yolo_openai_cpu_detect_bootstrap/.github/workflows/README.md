# GitHub Workflows

No CI workflow is defined in the bootstrap baseline.

A later PR should add CI after the first scaffold exists. Minimum expected CI:

- install dependencies;
- run `ruff check .`;
- run `python -m pytest`.
