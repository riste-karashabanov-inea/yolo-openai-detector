# Tests Directory

Implementation PRs must add pytest tests here.

The first implementation work order requires tests for authentication, `/v1/models`, image parsing, negative validation paths, and OpenAI-shaped response/error envelopes.
