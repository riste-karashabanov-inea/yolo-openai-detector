# OpenAI-Compatible CPU YOLO Single-Image Detection API

This repository is intended to implement a CPU-only object detection service with an OpenAI-compatible HTTP surface.

The service accepts exactly one image per request, supplied as a Base64 data URL in an OpenAI-style JSON request, runs YOLO object detection synchronously on CPU, and returns an OpenAI-shaped response containing a strict JSON detection payload.

## Project status

This repository bootstrap defines the project constitution, architecture, API contract, non-goals, and first implementation work order. The initial repository intentionally does not contain a working application yet. Implementation must proceed through PR-sized work orders after this baseline is committed.

## Product promise

A client that can call an OpenAI-style API with Bearer authentication should be able to send one attached image and receive deterministic, schema-stable object detections from a local CPU-only YOLO runtime.

## Required API surface

| Endpoint | Purpose | Required for first implementation |
|---|---|---:|
| `GET /health` | Operational health check | Yes |
| `GET /v1/models` | OpenAI-compatible model discovery | Yes |
| `POST /v1/responses` | Single-image object detection | Yes |

## Compatibility target

The project is OpenAI-compatible in API style, not a general OpenAI proxy.

Compatibility decisions:

- Use `Authorization: Bearer <fixed_api_key>`.
- Use `/v1/models` to expose the locally configured detector model.
- Use `/v1/responses` for a synchronous single-image request.
- Accept image input as a Base64 data URL in OpenAI Responses-style input content.
- Return an OpenAI-shaped response object whose output text contains strict detection JSON.

References for implementers:

- OpenAI API authentication overview: https://developers.openai.com/api/reference/overview
- OpenAI Images and Vision guide: https://developers.openai.com/api/docs/guides/images-vision
- OpenAI model documentation: https://developers.openai.com/api/docs/models

## First supported request shape

```json
{
  "model": "yolo-cpu-detect",
  "input": [
    {
      "role": "user",
      "content": [
        {
          "type": "input_text",
          "text": "Detect objects in this image."
        },
        {
          "type": "input_image",
          "image_url": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQ..."
        }
      ]
    }
  ]
}
```

## First supported detection payload

The OpenAI-shaped response contains output text with JSON equivalent to:

```json
{
  "detections": [
    {
      "class_id": 0,
      "class_name": "person",
      "confidence": 0.91,
      "bbox_xyxy": [120.4, 44.1, 188.2, 210.8]
    }
  ],
  "image": {
    "width": 1280,
    "height": 720
  },
  "runtime": {
    "backend": "fake",
    "device": "cpu",
    "inference_ms": 0.0
  }
}
```

## Non-goals for the first release

This project must not implement the following in the first release:

- object tracking;
- segmentation;
- video input;
- webcam input;
- streaming image processing;
- background jobs;
- job IDs;
- database persistence;
- persistent image storage;
- GPU inference;
- CUDA;
- TensorRT;
- calling OpenAI upstream APIs;
- multi-tenant key management;
- user management;
- billing or quota management.

## Expected repository workflow after bootstrap

1. Commit this bootstrap as the initial repository baseline.
2. Use `docs/work-orders/WO-001-scaffold.md` as the first coding-agent task.
3. Implement through a feature branch and pull request.
4. Require tests and a final agent report before merge.
5. Keep `AGENTS.md` and `CLAUDE.md` aligned whenever project law changes.

## Project files to read first

| File | Purpose |
|---|---|
| `AGENTS.md` | Primary project constitution for coding agents |
| `CLAUDE.md` | Equivalent project constitution for Claude Code workflows |
| `docs/project-baseline.md` | Approved baseline scope and assumptions |
| `docs/api-contract.md` | HTTP contract and schema rules |
| `docs/non-goals.md` | Explicit exclusions and scope guardrails |
| `docs/work-orders/WO-001-scaffold.md` | First implementation task |

## Current implementation state

No production code has been implemented yet. Empty directories are intentionally preserved with `.gitkeep` files.
